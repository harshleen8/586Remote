﻿namespace Project1_586
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var remoteButtons = new HashSet<string>() {
                "on","off","ch+","channel-","vol+","vol-","mute","settings","menu","back","help","escape"
            };
            var modelValues = new Dictionary<string, long>() {
                {"UN43",100},
                {"UN50",101},
                {"UN55",102},
                {"UN58",103},
                {"UN65",104},
                {"UN70",105},
                {"UN75",106}
                
            };
            string message;
            samsungModelValues(modelValues);
            samsungInstructions();
            do
            {
                Thread.Sleep(7000);
                samsungRemote();
                message = RemoteMessage(remoteButtons);
                if (message == "escape")
                {
                    continue;
                }
                else if (message == "help")
                {
                    samsungInstructions();
                }
                else
                {
                    samsungRemote();
                }
            } while (message != "escape");
                
        }
        static public string samsungModelValues(Dictionary<string, long> Screen)
        {
            string key;
            bool result = false;

            do
            {
                Console.WriteLine("TV Screen Models: [UN43],[UN50],[UN55],[UN58],[UN65],[UN70],[UN75]");
                Console.Write("Provide any model number for Samsung series: ");
                key = Console.ReadLine();
                key = key == null ? "" : key;
                result = Screen.ContainsKey(key);
                if (!result) { Console.WriteLine("Please try again.!"); }
            } while (!result);
            return key;
        }
        static public void samsungRemote()
        {
            Console.WriteLine("||-----------------||");
            Console.WriteLine("||-----------------||");
            Console.WriteLine("|--SAMSUNG TV REMOTE--|");
            Console.WriteLine("|[  On ]         [ Off ]|");
            Console.WriteLine("|[   1    ][    2   ][    3   ]|");
            Console.WriteLine("|[   4    ][    5   ][    6   ]|");
            Console.WriteLine("|[   7    ][    8   ][    9   ]|");
            Console.WriteLine("|[  MUTE  ][    0   ][ SETTINGS ]|");
            Console.WriteLine("|[    +   ][    ][    +   ]|");
            Console.WriteLine("|[ VOLUME ][  DVD  ][ CHANNEL ]|");
            Console.WriteLine("|[    -   ][  MODE  ][    -   ]|");
            Console.WriteLine("|------------------------------|");
            Console.WriteLine("|[  BACK  ]          [  HELP  ]|");
        }
        static public void samsungInstructions()
        {
            Console.WriteLine("Welcome to Samsung TV");
            Console.WriteLine("Please enter your selection");
            Console.WriteLine("Turn On - turns on your tv");
            Console.WriteLine("Turn Off - turns off your tv");
            Console.WriteLine("Volume Up - turns up the volume");
            Console.WriteLine("Volume Down - turns down the volume");
            Console.WriteLine("Channel Up - increments the channel");
            Console.WriteLine("Channel Down - decrements the channel");
            Console.WriteLine("TV Mode- set TV mode");
            Console.WriteLine("DVD Mode- set DVD mode");
            Console.WriteLine();
            Console.Write("Press Enter key to proceed");
            Console.ReadLine();
        }
        static public string RemoteMessage(HashSet<string> validCommands)
        {
            string message = "";
            bool valid = false;
            do
            {
                Console.Write("\n Enter value: ");
                message = Console.ReadLine();
                if (Int32.TryParse(message, out int val))
                {
                    valid = true;
                }
                    if (message.Equals("On") == true)
                        Console.WriteLine("TV has been turned {0} ", message);
                    if (message.Equals("Off") == true)
                        Console.WriteLine("TV has been turned {0} ", message);
                    if (message.Equals("volume+") == true)
                        Console.WriteLine("TV volume has been incremented by 1 ", message);
                    if (message.Equals("volume-") == true)
                            Console.WriteLine("TV volume has been decremented by 1 ", message);
                    if (message.Equals("channel+") == true)
                        Console.WriteLine("TV chnanel has been changed to 2 ", message);
                    if (message.Equals("channel-") == true)
                        Console.WriteLine("TV chnanel has been changed to 1 ", message);
                    if (message.Equals("mute") == true)
                         Console.WriteLine("TV has now been muted ", message);
                else if (validCommands.Contains(message)) valid = true;
                else
                {
                    valid = false;
                }
            } while (!valid);
            return message;
        }
    }
}