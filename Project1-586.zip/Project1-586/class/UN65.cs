﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1_586
{
    internal class UN65 : Screen
    {
        public override void tvMenu(string message)
        {
            if (message.Equals("menu") && this.power == true)
                Console.WriteLine("UN65 Menu selected:");
        }
        public override void tvSettings(string message)
        {
            if (message.Equals("settings") && this.power == true)
            {
                Console.WriteLine("UN65 Settings: ");
            }
        }
    }
}
