﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1_586
{
    internal class UN58 : Screen
    {
        public override void tvMenu(string message)
        {
            if (message.Equals("menu") && this.power == true)
                Console.WriteLine("UN58 Menu selected:");
        }
        public override void tvSettings(string message)
        {
            if (message.Equals("settings") && this.power == true)
            {
                Console.WriteLine("UN58 Settings: ");
            }
        }
    }
}
