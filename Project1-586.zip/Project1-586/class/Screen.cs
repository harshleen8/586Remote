﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1_586
{
    public abstract class Screen : RemoteInterface
    {
        protected bool power;
        protected bool mute;
        protected int channel;
        protected int volume;
        protected int lastChannel;
        protected static int maxChannel;
        protected static int maxVolume;
        protected static int minChannel;
        protected static int minVolume;

        static Screen()
        {
            maxChannel = 999;
            maxVolume = 100;
            minChannel = 1;
            minVolume = 0;
        }

        public void powerOnOff(string message)
        {
            if (message.Equals("power"))
            {
                this.power = !this.power ? true : false;
            }
        }

        public void muteTV(string message)
        {
            if (message.Equals("mute") && this.power == true)
            {
                this.mute = !this.mute ? true : false;
            }
        }

        public void volumeUpDown(string message)
        {
            bool volIncr = message.Equals("vol+");
            bool volDec = message.Equals("vol-");
            if ((volIncr || volDec) && this.power == true)
            {
                if (volIncr)
                    this.volume = this.volume < maxVolume ? ++this.volume : this.volume;

                if (volDec)
                    this.volume = this.volume > minVolume ? --this.volume : this.volume;

                this.mute = false;
            }
        }

        public void channelUpDown(string message)
        {
            if (this.power == true)
            {
                if (int.TryParse(message, out int value))
                {
                    if (value <= maxChannel && value >= minChannel)
                    {
                        this.lastChannel = this.channel;
                        this.channel = value;
                    }
                }
                else if (message.Equals("channel+"))
                {
                    if (this.channel < maxChannel)
                    {
                        this.lastChannel = this.channel;
                        this.channel++;
                    }
                }
                }
                else if (message.Equals("channel-"))
                {
                    if (this.channel > minChannel)
                    {
                        this.lastChannel = this.channel;
                        this.channel--;
                    }
                }
            }
            public void setTVMode(string message)
            {
                if(this.power== false)
                {
                    Console.WriteLine("TV is off");
                }
                else
                {
                    Console.WriteLine("TV Mode has been set");
                }
            }
            public void setDVDMode(string message)
            {
                if (this.power == false)
                {
                    Console.WriteLine("TV is off");
                }
                else
                {
                    Console.WriteLine("DVD Mode has been set");
                }
            }
            public abstract void tvMenu(string message);

            public abstract void tvSettings(string message);
    }

}
