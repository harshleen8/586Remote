﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1_586
{
    public interface RemoteInterface
    {
        void powerOnOff(string message);
        void muteTV(string message);
        void volumeUpDown(string message);
        void channelUpDown(string message);
        void setTVMode(string message);
        void setDVDMode(string message);
    }
}
